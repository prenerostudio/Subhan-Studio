      </div>
   
	
	
    
	<script src="js/jquery-1.10.2.js"></script>
     
	
    
	<script src="js/bootstrap.min.js"></script>
    
	
    
	<script src="js/jquery.metisMenu.js"></script>
    
	
     
	<script src="js/morris/raphael-2.1.0.min.js"></script>
    
	<script src="js/morris/morris.js"></script>
     
     <!-- DATA TABLE SCRIPTS -->
    <script src="js/dataTables/jquery.dataTables.js"></script>
    <script src="js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#wedding').dataTable();
            });
    </script>
	
    
	<script src="js/custom.js"></script>
    
   

	</body>

</html>
