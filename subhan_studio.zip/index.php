<?php
include('header.php');
?>
			
			<!-- Start Slider Are -->
			<section id="atf-slider" class="atf-slider atf-slider-parallax">
				<div class="swiper-container atf-parallax-slider">
					<div class="swiper-wrapper">
						<div class="swiper-slide">
							<div class="atf-swiper-img atf-align-item-center" data-background="img/slider/2.jpg" data-overlay-dark="6">
								<div class="container">
									<div class="row justify-content-center">
										<div class="col-lg-8 text-center">
											<div class="atf-slider-content">
												<h1>Event Photographer</h1>
												<p>Subhan Photo Studio is a photography studio known for its expertise in capturing memorable moments and creating striking images, offering a range of photography services for various occasions and subjects.</p>
												<div class="atf-main-btn mt-5">
													<a class="atf-themes-btn" href="about.php" data-hover="Read More">
														<span>Read More</span>
													</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						
						<div class="swiper-slide">
							<div class="atf-swiper-img atf-align-item-center" data-background="img/slider/1.jpg" data-overlay-dark="6">
								<div class="container">
									<div class="row justify-content-center">
										<div class="col-lg-8 text-center">
											<div class="atf-slider-content">
												<h1>Event Photographer</h1>
												<p>Subhan Photo Studio is a photography studio known for its expertise in capturing memorable moments and creating striking images, offering a range of photography services for various occasions and subjects.</p>
												<div class="atf-main-btn mt-5">
													<a class="atf-themes-btn" href="about.php" data-hover="Read More">
														<span>Read More</span>
													</a>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- slider setting -->
					<div class="swiper-control-btn">
						<div class="swiper-button-prev swiper-nav-control prev-control">
							<span class="arrow"></span>
						</div>
						<div class="swiper-button-next swiper-nav-control next-control">
							<span class="arrow"></span>
						</div>
					</div>
					<div class="swiper-pagination"></div>
				</div>
			</section>
			<!-- End Slider Area -->


<section id="project" class="atf-section-padding">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-12 col-md-12 col-12">
							<div class="atf-section-title text-center wow zoomIn" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
								<h5 class="atf-sheading">Best Photo and Videographer in Faisalabad.</h5>
								<h2 class="">Welcome to our <strong>Subhan Studio</strong> </h2>
								<p class="">Subhan Studio is a group of highly experienced and professional photographers of Faisalabad. We believe wedding photography is all about sensing and capturing precious moment of the event for future view of the bride and groom as they are busy in their own rituals. On wedding events bride and groom are totally busy in their own rituals that they are not able to witness all the laughers, emotions and moments of joys from their own eyes. So our wedding photography should be exactly like as if the bride and groom are at their wedding function.</p>
							</div>
						</div><!--- END COL -->
					</div><!--- END ROW -->

				
				</div><!--- END CONTAINER -->
			</section>
		

			 <!-- About Section Start -->
            <div id="about" class="atf-about style1 atf-section-padding">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-12">
							<div class="about-image">
                                <img src="img/about/about-side-1.jpg" alt="">
                            </div>
                        </div>
                       <div class="col-xl-6 col-12 align-self-center mt-xl-40">
                            <div class="atf-section-title">
                                <h5>About Us</h5>
                                <h2 class="">We're photographer & video grapher about 20+ Years.</h2>
                                <p class="" align="justify">Elevate Your Photography and Videography with Subhan Studio: The Best Photographer and Videographer in Faisalabad In today's visual-centric world, the significance of photography and videography cannot be overstated. Whether you're capturing life's precious moments, creating content for social media, or professionally documenting events, having the right tools at your disposal can make all the difference. This is where Subhan Studio, renowned as the best photographer and videographer in Faisalabad, steps in to offer a comprehensive range of digital camera gadgets that can elevate your visual storytelling to new heights. The Artistry of Subhan Studio With an impeccable reputation in Faisalabad, Subhan Studio has earned its place as a trailblazer in the world of photography and videography. Led by a team of creative and passionate professionals, the studio is known for its exceptional ability to capture the essence of each moment, transforming it into a timeless piece of art. Unveiling the Power of Digital Camera Gadgets Subhan Studio's commitment to excellence extends beyond skill and vision. They recognize that having the right tools can significantly enhance the creative process. Let's delve into some of the remarkable digital camera gadgets offered by Subhan Studio that cater to both photographers and videographers:</p>
                            </div>
                            <ul class="listing-style">
                                <li>High-Resolution DSLR and Mirrorless Cameras </li>
                                <li>Professional-Grade Lenses Lenses </li>
                                <li>Stabilization and Support Systems  </li>
                                <li>External Microphones and Audio Accessories  </li>
								<li>Drone Technology Aerial  </li>
								<li>High-End Editing Software   </li>
                            </ul>
                            <div class="atf-about-btn mt-4 pt-2">
                                <a class="atf-themes-btn" href="about.php" data-hover="about us"> <span>about us</span></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- About Section End -->
			
			
			<!-- START SERVICE -->
			<section id="project" class="atf-section-padding">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-12 col-md-12 col-12">
							<div class="atf-section-title text-center wow zoomIn" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
								<h5 class="atf-sheading"> We Offer</h5>
								<h2 class="">Our Services</h2>
								<p class="">Our services encompass a wide range of offerings, including professional photography for events, portraits, weddings, product shoots, and creative projects. We also provide image editing and retouching services to enhance the quality of your photos. Our team is dedicated to delivering exceptional visual content tailored to your needs.</p>
							</div>
						</div><!--- END COL -->
					</div><!--- END ROW -->

					<div class="row">			
						<div class="col-md-12">
							<div id="atf-home-active" class="atf-main-testimonials atf-testimonial-slider owl-carousel owl-theme">
								<div class="atf-best-service-slide">
									<div class="atf-best-service-img">
										
										<a href="img/services/service-makeup.jpg" data-rel="lightcase:myCollection">
											<img src="img/services/service-makeup.jpg" alt="Blog">
										</a> 
									</div>
									
									<div class="atf-best-service-content text-center">
										<h3 class="atf-best-service-title">
											<a href="#">Event Make Up</a>
										</h3>
										
										<p class="atf-best-service-description">We have professional Beautition who deal Bridal MakeUp, Party MakeUp, Hair dye.</p>
									</div>
								</div>
								
								<div class="atf-best-service-slide">
									<div class="atf-best-service-img">
										<a href="img/services/event-photo.jpg" data-rel="lightcase:myCollection">
											<img src="img/services/event-photo.jpg" alt="Blog"></a> 
									</div>
									<div class="atf-best-service-content text-center">
										<h3 class="atf-best-service-title"><a href="#">Event Photography</a></h3>
										<p class="atf-best-service-description">We deal All type of photography include Wedding, corporate and Product photography.</p>
									</div>
								</div>
								
								<div class="atf-best-service-slide">
									<div class="atf-best-service-img">
										<a href="img/services/stage.jpg" data-rel="lightcase:myCollection">
											<img src="img/services/stage.jpg" alt="Blog"></a> 
									</div>
									<div class="atf-best-service-content text-center">
										<h3 class="atf-best-service-title"><a href="#">Decor Floor</a></h3>
										<p class="atf-best-service-description">We have Decorated stage lighten floor digital lights and flower Decoration</p>
									</div>
								</div>
								
								<div class="atf-best-service-slide">
									<div class="atf-best-service-img">
										<a href="img/services/service-dj.jpg" data-rel="lightcase:myCollection">
											<img src="img/services/service-dj.jpg" alt="Blog"></a> 
									</div>
									<div class="atf-best-service-content text-center">
										<h3 class="atf-best-service-title"><a href="#">DJ Sound</a></h3>
										<p class="atf-best-service-description">We deal all king of DJ Sound with base Kit and SMD (Surface Mount Device).</p>
									</div>
								</div>
							</div>
						</div>
					</div><!--- END ROW -->
				</div><!--- END CONTAINER -->
			</section>
			<!-- END SERVICE -->
			
			<!-- START COMPANY BRAND LOGO  -->
			<div id="atf-brand-area" class="atf-section-padding">
				<div class="atf-brand-overlay">
					<div class="container">
						<div class="row clearfix">
							<div class="col-md-12 col-lg-12">
								<div class="atf-brand-active owl-carousel">
									<a href="#"><img src="img/partner/Grand City.jpg" alt="image"></a>
									<a href="#"><img src="img/partner/Peramount.png" alt="image"></a>
									<a href="#"><img src="img/partner/Skin care.jpg" alt="image"></a>
									<a href="#"><img src="img/partner/spirit-school-logo.png" alt="image"></a>
									<a href="#"><img src="img/partner/superior colleges.png" alt="image"></a>
									<a href="#"><img src="img/partner/Superior.png" alt="image"></a>
									<!--<a href="#"><img src="img/partner/2.png" alt="image"></a>
									<a href="#"><img src="img/partner/3.png" alt="image"></a>
									<a href="#"><img src="img/partner/4.png" alt="image"></a>
									<a href="#"><img src="img/partner/5.png" alt="image"></a>-->
								</div>
							</div><!-- END COL  -->
						</div><!--END  ROW  -->
					</div><!-- END CONTAINER  -->
				</div><!-- END OVERLAY -->
			</div>
			<!-- END COMPANY BRAND LOGO -->	
			
			
			<!-- START HIRE -->
			<div class="atf-hire">
				<div class="container">
					<div class="row atf-hire-area">
						<div class="col-xl-8 col-12">
							<div class="atf-hire-inner">
								<div class="atf-hire-content">
									<h3>Prepare For your Photo & Video Service</h3>
									<p>Are you looking for best photographer for your Function?</p>
								</div>
							</div>
						</div><!--- END COL -->
						<div class="col-xl-4 col-12 atf-hire-btn text-end mt-lg-40 mt-3">
							<a href="contact.php" class="atf-themes-btn" data-hover="Get Start Now"> <span>Get Start Now</span> </a>
						</div>
					</div><!--- END ROW -->
				</div><!--- END CONTAINER -->
			</div>
			<!-- END HIRE-->
			
			
					
			<!-- TESTIMONIAL SECTION START-->
			<section id="testimonial" class="atf-section-padding">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-6 col-md-7 col-12">
							<div class="atf-section-title text-center wow zoomIn" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
								<h5 class="atf-sheading"> Testimonial</h5>
								<h2 class="text-white">Client Feedback</h2>
								<p class="text-white">Lorem ipsum dolor sit amet elit , consectetur adipiscing , sed eiusmod tempor sit amet elit dolor sit amet elit.</p>
							</div>
						</div><!--- END COL -->
					</div><!--- END ROW -->
					
	
					<div class="row">	
						<!-- Testimonials section Starts-->
						<div class="col-lg-12">
							<div id="testimonial-slider" class="atf-testimonials-slide atf-main-testimonials atf-testimonial-slider owl-carousel owl-theme">
								<div class="testimonial">
									<div class="pic">
										<img src="img/portfolio/1.jpg" alt="Portfolio Image">
									</div>
									<h3 class="testimonial-title">Abdul Mubdi</h3>
									<small class="post">Web Designer</small>
									<p class="description">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at ornare eros. Proin nec pulvinar augue, at.
									</p>
								</div>
								
								<div class="testimonial">
									<div class="pic">
										<img src="img/portfolio/2.jpg" alt="Portfolio Image">
									</div>
									<h3 class="testimonial-title">Abdul Mushi</h3>
									<small class="post">Web Developer</small>
									<p class="description">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at ornare eros. Proin nec pulvinar augue, at.
									</p>
								</div>
								
								<div class="testimonial">
									<div class="pic">
										<img src="img/portfolio/3.jpg" alt="Portfolio Image">
									</div>
									<h3 class="testimonial-title">Abdul Hasib</h3>
									<small class="post">Web Developer</small>
									<p class="description">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at ornare eros. Proin nec pulvinar augue, at.
									</p>
								</div>
								
								<div class="testimonial">
									<div class="pic">
										<img src="img/portfolio/1.jpg" alt="Portfolio Image">
									</div>
									<h3 class="testimonial-title">Abdul Wahid</h3>
									<small class="post">Web Developer</small>
									<p class="description">
										Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam at ornare eros. Proin nec pulvinar augue, at.
									</p>
								</div>
							</div>
						</div><!--- END COL -->
					</div><!--- END ROW -->
				</div><!--- END CONTAINER -->
			</section>
			<!-- TESTIMONIAL SECTION END-->
		   
			<section id="pricing" class="atf-pricing-area atf-section-padding">
				<div class="container">
					<div class="row">
						<div class="col-lg-4 col-md-6 col-12">
							<div class="pricingTable">
								<div class="pricingTable-header">
									<div class="price-value">
										<span class="amount">55,000</span>
										<span class="currency">PKR</span>
										<!--<span class="duration">per-month</span>-->
									</div>
								</div>
								<h2 class="title">Basic</h2>
								<ul class="pricing-content">
									<li>1 Wedding photographer</li>
									<li>Bride & Groom Photoshoot</li>
									<li>10 Page krizma album</li>
									<li>Full Event Video</li>
									<li>300 soft copies</li>
									<li class="disable">1 Day Drone Camera</li>
									
									<li class="disable">Cinematic Video Highlight</li>
									<li class="disable">Family Interview</li>
									<li class="disable">Each Day Teaser</li>
									<li class="disable">Canded Event Coverage</li>
									<li class="disable">2 Photo Frame</li>
								</ul>
								<div class="atf-about-btn">
									<a class="atf-themes-btn" data-hover="Contact Us" href="contact.php">
										<span> Contact Us</span>
									</a>
								</div>	
							</div>
						</div>
						
						<div class="col-lg-4 col-md-6 col-12">
							<div class="pricingTable">
								<div class="pricingTable-header">
									<div class="price-value">
										<span class="amount">75,000</span>
										<span class="currency">PKR</span>
										<!--<span class="duration">per-month</span>-->
									</div>
								</div>
								<h2 class="title">Standard</h2>
								<ul class="pricing-content">
									<li>2 Wedding photographer</li>
									<li>Bride & Groom Photoshoot</li>
									<li>10 Page 2 krizma album</li>
									<li>Full Event Video double camera</li>
									<li>500 soft copies</li>
									<li>1 Day Drone Camera</li>
									<li>Cinematic Video Highlight</li>
									<li class="disable">Family Interview</li>
									<li class="disable">Each Day Teaser</li>
									<li class="disable">Canded Event Coverage</li>
									<li class="disable">2 Photo Frame</li>
								</ul>
								<div class="atf-about-btn">
									<a class="atf-themes-btn" data-hover="Contact Us" href="contact.php">
										<span> Contact Us</span>
									</a>
								</div>	
							</div>
						</div>
						<div class="col-lg-4 col-md-6 col-12">
							<div class="pricingTable">
								<div class="pricingTable-header">
									<div class="price-value">
										<span class="amount">170,000</span>
										<span class="currency">PKR</span>
										<!--<span class="duration">per-month</span>-->
									</div>
								</div>
								<h2 class="title">Premium</h2>
								<ul class="pricing-content">
									










									<li>3 Senior Wedding photographer</li>
									<li>Bride & Groom Photoshoot</li>
									<li>10 Page 4 krizma album</li>
									<li class="">Full Event Video double camera</li>
									<li class="">3 Days drone Coverage</li>
									
									<li>Family Interview</li>
									<li>Each Day Teaser</li>
									<li>Canded Event Coverage</li>
									<li class="">2 Photo Frame</li>
									<li class="">All soft copies</li>
									<li class="">Cinematic Video Highlight</li>
								</ul>
								<div class="atf-about-btn">
									<a class="atf-themes-btn" data-hover="Contact Us" href="contact.php">
										<span> Contact Us</span>
									</a>
								</div>	
							</div>
						</div>
					</div>
				</div>
			</section>
			
			<!-- START  PROCESS SECTION-->
			<section id="processing" class="atf-processing-area atf-section-padding">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-6 col-md-7 col-12">
							<div class="atf-section-title text-center wow zoomIn" data-wow-duration="1s" data-wow-delay="0.3s" data-wow-offset="0">
								<h5 class="atf-sheading">Process</h5>
								<h2 class="">Our Processing</h2>
								
							</div>
						</div><!--- END COL -->
					</div><!--- END ROW -->
					
					<div class="row">
						<div class="col-lg-3 col-md-6">
							<div class="process">
								<div class="process-icon">
									<span><i class="fa fa-globe"></i></span>
								</div>
								<h3 class="title">Editing <span>Process</span></h3>
								
							</div>
						</div>
						
						<div class="col-lg-3 col-md-6">
							<div class="process">
								<div class="process-icon">
									<span><i class="fa fa-rocket"></i></span>
								</div>
								<h3 class="title">Video <span>Graphic</span></h3>
								
							</div>
						</div>
						
						<div class="col-lg-3 col-md-6">
							<div class="process">
								<div class="process-icon">
									<span><i class="fa fa-rocket"></i></span>
								</div>
								<h3 class="title">Final <span>Shoting</span></h3>
								
							</div>
						</div>
						
						<div class="col-lg-3 col-md-6">
							<div class="process">
								<div class="process-icon">
									<span><i class="fa fa-rocket"></i></span>
								</div>
								<h3 class="title">Photo <span>Graphy</span></h3>
								
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- END  PROCESS SECTION-->

	
			
		<?php
			include('footer.php');
			?>
		